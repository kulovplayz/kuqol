package com.bogdan.qol.Features.QOL;

class BookTypePos {

    public int slot;

    public String type;

    public int level;

    public BookTypePos(String var1, int var2, int var3) {
        this.type = var1;
        this.level = var2;
        this.slot = var3;
    }
}
