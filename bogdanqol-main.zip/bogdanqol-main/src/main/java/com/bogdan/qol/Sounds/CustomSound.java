package com.bogdan.qol.Sounds;

public class CustomSound extends Sound {
    public CustomSound(String var1, float var2) {
        super(var1, var2);
    }

    public CustomSound(String var1) {
        this(var1, 1.0F);
    }
}
