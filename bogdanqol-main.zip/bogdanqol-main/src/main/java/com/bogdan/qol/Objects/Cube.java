package com.bogdan.qol.Objects;

import java.awt.*;

public class Cube {

    public double h;

    public double z;

    public double w;

    public double y;

    public Color color = new Color(0, 255, 0);

    public double x;

    public Cube(double var1, double var3, double var5, double var7, double var9) {
        this.x = var1;
        this.y = var3;
        this.z = var5;
        this.h = var7;
        this.w = var9;
    }
}
