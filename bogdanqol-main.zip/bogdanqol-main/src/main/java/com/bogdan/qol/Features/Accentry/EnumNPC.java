package com.bogdan.qol.Features.Accentry;

enum EnumNPC {

    NONE,

    JY,

    XNH,

    CXK
}
