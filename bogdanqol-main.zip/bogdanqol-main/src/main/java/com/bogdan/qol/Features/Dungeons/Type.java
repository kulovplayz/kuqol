package com.bogdan.qol.Features.Dungeons;

enum Type {

    EMPTY,

    PATH,

    START,

    END
}
