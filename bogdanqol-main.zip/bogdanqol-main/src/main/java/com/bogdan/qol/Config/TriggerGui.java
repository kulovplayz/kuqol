package com.bogdan.qol.Config;

public class TriggerGui {
}
