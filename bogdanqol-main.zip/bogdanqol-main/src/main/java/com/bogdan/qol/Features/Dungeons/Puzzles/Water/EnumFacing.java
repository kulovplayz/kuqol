package com.bogdan.qol.Features.Dungeons.Puzzles.Water;

public enum EnumFacing {

    zp,

    zn,

    xp,

    xn
}
