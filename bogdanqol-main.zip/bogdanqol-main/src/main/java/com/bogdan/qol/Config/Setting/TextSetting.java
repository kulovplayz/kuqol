package com.bogdan.qol.Config.Setting;

import com.bogdan.qol.Config.Property;

import java.lang.reflect.Field;

public class TextSetting extends Setting {
    public TextSetting(Property var1, Field var2) {
        super(var1, var2);
    }

    public boolean set(Object var1) {
        return super.set(var1);
    }
}
