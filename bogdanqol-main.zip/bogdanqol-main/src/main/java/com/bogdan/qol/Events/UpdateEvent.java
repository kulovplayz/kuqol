package com.bogdan.qol.Events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class UpdateEvent extends Event {
}
