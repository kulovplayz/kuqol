package com.bogdan.qol.Features.Remote.API;

public class ApiException extends Exception {
    public ApiException(String var1) {
        super(var1);
    }
}
