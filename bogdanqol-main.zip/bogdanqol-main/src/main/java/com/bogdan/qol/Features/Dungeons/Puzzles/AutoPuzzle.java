package com.bogdan.qol.Features.Dungeons.Puzzles;

import com.bogdan.qol.Objects.KeyBind;

public class AutoPuzzle {

    public static final KeyBind keyBind = new KeyBind("Auto Puzzles", 0);
}
