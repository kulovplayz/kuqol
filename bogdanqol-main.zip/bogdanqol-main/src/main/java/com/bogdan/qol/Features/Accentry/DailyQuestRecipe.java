package com.bogdan.qol.Features.Accentry;

class DailyQuestRecipe {

    public int count;

    public String name;

    public DailyQuestRecipe(String var1, int var2) {
        this.name = var1;
        this.count = var2;
    }
}
