package com.bogdan.qol.Features.Dungeons.Puzzles.Water;

public enum EnumState {

    B,

    E,

    c,

    g,

    q,

    d,

    e,

    cl,

    cc,

    cg,

    cq,

    cd,

    ce,

    ccl,

    w,

    w1,

    w2,

    w3,

    w4,

    w5,

    w6,

    w7,

    w8
}
