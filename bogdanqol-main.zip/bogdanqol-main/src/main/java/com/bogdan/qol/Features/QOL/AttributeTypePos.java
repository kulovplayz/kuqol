package com.bogdan.qol.Features.QOL;

class AttributeTypePos {

    public int level2;

    public int slot;

    public int level1;

    public AttributeTypePos(int var1, int var2, int var3) {
        this.level1 = var1;
        this.level2 = var2;
        this.slot = var3;
    }
}
