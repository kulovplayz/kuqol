package com.bogdan.qol.Features.Dungeons.Puzzles.Water;

public enum EnumOperation {

    trig,

    e,

    c,

    g,

    q,

    d,

    cl,

    empty
}
