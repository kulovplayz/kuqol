package com.bogdan.qol.utils;

import net.minecraft.util.Session;

public class SessionUtils {
    public static boolean isDev() {
        return false;
    }
}
