package com.bogdan.qol.Commands;

enum EnumFarmingType {

    VERTICAL,

    PUMPKIN
}
