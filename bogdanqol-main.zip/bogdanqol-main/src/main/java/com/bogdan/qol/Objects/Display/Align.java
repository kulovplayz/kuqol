package com.bogdan.qol.Objects.Display;

enum Align {

    LEFT,

    CENTER,

    RIGHT
}
