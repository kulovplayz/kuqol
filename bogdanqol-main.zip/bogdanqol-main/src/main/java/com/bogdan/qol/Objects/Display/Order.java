package com.bogdan.qol.Objects.Display;

enum Order {

    UP,

    DOWN
}
