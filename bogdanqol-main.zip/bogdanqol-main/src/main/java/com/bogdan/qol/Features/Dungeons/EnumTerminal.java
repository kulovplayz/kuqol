package com.bogdan.qol.Features.Dungeons;

enum EnumTerminal {

    NONE,

    ORDER,

    MAZE,

    CORRECT,

    START,

    COLOR,

    COLORPAD
}
