package com.bogdan.qol.Features.Nether.Dojo;

public enum EnumDojoTask {

    FORCE,

    STAMINA,

    MASTERY,

    DISCIPLINE,

    SWIFTNESS,

    CONTROL,

    TENACITY
}
