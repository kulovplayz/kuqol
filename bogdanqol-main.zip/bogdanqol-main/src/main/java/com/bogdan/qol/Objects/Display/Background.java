package com.bogdan.qol.Objects.Display;

enum Background {

    NONE,

    FULL,

    PER_LINE
}
