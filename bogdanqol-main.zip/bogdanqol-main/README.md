# bogdanqol
### Bogdan QOL is a mod made by me with a little help from friends
### It is a hybrid between legit and cheater mod, if you don't want to cheat don't turn on anything that sounds sus
### All flagging features have a warning above them
### To open gui run /bn s
## cool gui:
![](https://media.discordapp.net/attachments/1100449833929687110/1101839877177352222/image.png?width=1150&height=615)
### If you want to know features read the names of the files in: https://github.com/bogdaniscool/bogdanqol/tree/main/src/main/java/com/bogdan/qol/Features
